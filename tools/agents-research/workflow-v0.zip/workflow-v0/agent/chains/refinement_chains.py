from pydantic import BaseModel, Field
from typing import Literal, List, Optional
from langchain_core.prompts import ChatPromptTemplate

# --- 1. Refinement Planning (The Brain) ---

class PruneTarget(BaseModel):
    object_type: Literal["table", "column", "metric"] = Field(..., description="Tipo oggetto da rimuovere")
    name: str = Field(..., description="Nome dell'oggetto")
    reason: str = Field(..., description="Motivo rapido")

class FetchTarget(BaseModel):
    search_text: str = Field(..., description="Cosa cercare (es. 'tassi cambio')")
    expected_type: Literal["table", "column", "metric", "golden_sql"] = Field(..., description="Cosa ti aspetti di trovare")

class RefinementAction(BaseModel):
    """Decisione strategica sul prossimo passo."""
    status_reasoning: str = Field(..., description="Riflessione sullo stato attuale del contesto.")
    action_type: Literal["PRUNE", "FETCH", "READY"] = Field(..., description="Azione decisa.")
    prune_targets: Optional[List[PruneTarget]] = Field(None, description="Se action=PRUNE")
    fetch_targets: Optional[List[FetchTarget]] = Field(None, description="Se action=FETCH")

REFINEMENT_SYSTEM_PROMPT = """Sei un Senior Data Engineer. Stai costruendo il contesto ideale per generare una query SQL.
Il tuo obiettivo è raffinare il 'working_datasource'.

Domanda Utente: {question}

Contesto Attuale:
{context_snapshot}

Analizza il contesto rispetto alla domanda:
1. PRUNE: C'è "rumore"? Tabelle o colonne chiaramente inutili che potrebbero confondere il generatore SQL?
   - Agisci in modo conservativo: rimuovi solo se sei sicuro che sia irrilevante.
2. FETCH: Mancano informazioni critiche menzionate nella domanda (es. una metrica specifica, una tabella di lookup)?
   - Se sì, specifica cosa cercare.
3. READY: Il contesto contiene tutte e sole le informazioni necessarie?
   - Se sì, dichiara READY.

IMPORTANTE:
- Non loopare all'infinito. Se hai già cercato e non trovato, o se hai potato tutto il potabile, vai su READY.
- Se il contesto è vuoto, DEVI fare FETCH.
"""

def get_refinement_planner(llm):
    return llm.with_structured_output(RefinementAction)


# --- 2. Search Evaluation (The Critic) ---

class SearchEvaluation(BaseModel):
    """Valuta se i risultati della ricerca sono utili."""
    reasoning: str = Field(..., description="Analisi della pertinenza rispetto alla domanda.")
    is_irrelevant: bool = Field(..., description="True se i risultati non servono.")
    formatted_note: str = Field(..., description="Testo pulito da aggiungere come 'Note' al contesto se rilevante.")

EVALUATOR_SYSTEM_PROMPT = """Hai cercato: '{search_text}'
Risultati trovati:
{results_snapshot}

Domanda Utente: {question}

Questi risultati aiutano a rispondere alla domanda?
Se sì, scrivi una nota sintetica da allegare al contesto (es. "La tabella X contiene i tassi di cambio").
Se no, scartali.
"""

def get_search_evaluator(llm):
    return llm.with_structured_output(SearchEvaluation)
