from pydantic import BaseModel, Field
from typing import List, Optional
from langchain_core.prompts import ChatPromptTemplate

# --- 1. Search Planning ---

class SearchPlan(BaseModel):
    """Pianifica la ricerca nel Knowledge Graph."""
    reasoning: str = Field(..., description="Analisi della richiesta utente e strategia di ricerca.")
    query_terms: List[str] = Field(..., description="Termini chiave estratti dalla domanda.")
    search_scope: List[str] = Field(..., description="Ambiti di ricerca (es. 'tables', 'columns').")

SEARCH_SYSTEM_PROMPT = """Sei un esperto Data Steward.
Analizza la domanda dell'utente e pianifica come cercare le informazioni nel Knowledge Graph.
Estrai i termini chiave più rilevanti.
Se la domanda è generica, cerca 'golden_sql' o 'tables'.
Se è specifica, cerca anche 'columns' e 'metrics'.

User Question: {question}
Analysis:"""

def get_search_planner(llm):
    return llm.with_structured_output(SearchPlan)

# --- 2. Datasource Selection ---

class DatasourceSelection(BaseModel):
    """Selezione del Datasource più rilevante."""
    reasoning: str = Field(..., description="Perché questo datasource è il migliore?")
    selected_datasource_slug: str = Field(..., description="Lo slug univoco del datasource scelto.")

SELECTION_SYSTEM_PROMPT = """Sei un SQL Architect.
Ho trovato i seguenti datasource candidati che potrebbero contenere la risposta:

{formatted_matches}

Domanda Utente: {question}

Analizza i candidati. Scegli SOLO il datasource che contiene le tabelle/colonne più rilevanti per rispondere NELLO SPECIFICO alla domanda.
Se nessuno sembra perfetto, scegli il più promettente.
"""

def get_datasource_selector(llm):
    return llm.with_structured_output(DatasourceSelection)
