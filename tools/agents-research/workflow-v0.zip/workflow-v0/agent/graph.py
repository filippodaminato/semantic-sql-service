from langgraph.graph import StateGraph, END
from agent.core.state import AgentState
from agent.nodes.retrieval_nodes import search_planner_node, retrieve_and_select_node
from agent.nodes.refinement_nodes import (
    refinement_planner_node,
    pruner_worker_node,
    fetch_worker_node,
    search_evaluator_node
)
from agent.tools.discovery_service import DiscoveryService

def build_graph(llm):
    """
    Constructs the Unified Agent Graph.
    """
    workflow = StateGraph(AgentState)
    
    # --- Dependencies ---
    service = DiscoveryService()
    
    # --- Node Wrappers (Dep Injection) ---
    async def call_search_planner(state):
        return await search_planner_node(state, llm)
        
    async def call_retriever(state):
        return await retrieve_and_select_node(state, llm, service)
        
    async def call_ref_planner(state):
        return await refinement_planner_node(state, llm)
    
    async def call_fetch_worker(state):
        return await fetch_worker_node(state, service)
        
    async def call_search_evaluator(state):
        return await search_evaluator_node(state, llm)
        
    # --- Add Nodes ---
    workflow.add_node("search_planner", call_search_planner)
    workflow.add_node("retriever", call_retriever)
    workflow.add_node("refinement_planner", call_ref_planner)
    workflow.add_node("pruner_worker", pruner_worker_node) # Sync
    workflow.add_node("fetch_worker", call_fetch_worker)
    workflow.add_node("search_evaluator", call_search_evaluator)
    
    # --- Edges: Phase 1 (Retrieval) ---
    workflow.set_entry_point("search_planner")
    workflow.add_edge("search_planner", "retriever")
    workflow.add_edge("retriever", "refinement_planner") # Seamless transition
    
    # --- Edges: Phase 2 (Refinement) ---
    
    def router(state):
        plan = state["refinement_plan"] # dict
        action = plan.get("action_type")
        
        # Safety Check
        if state["iterations"] > 5:
            return "end"
            
        if action == "PRUNE":
            return "pruner_worker"
        elif action == "FETCH":
            return "fetch_worker"
        elif action == "READY":
            return "end"
        
        return "end"

    workflow.add_conditional_edges(
        "refinement_planner",
        router,
        {
            "pruner_worker": "pruner_worker",
            "fetch_worker": "fetch_worker",
            "end": END
        }
    )
    
    workflow.add_edge("pruner_worker", "refinement_planner")
    workflow.add_edge("fetch_worker", "search_evaluator")
    workflow.add_edge("search_evaluator", "refinement_planner")
    
    return workflow.compile()
