import logging
from agent.core.state import AgentState
from agent.chains.refinement_chains import (
    get_refinement_planner,
    get_search_evaluator,
    REFINEMENT_SYSTEM_PROMPT,
    EVALUATOR_SYSTEM_PROMPT
)
from utils.context_formatter import AgentContextFormatter
from langchain_core.prompts import ChatPromptTemplate

logger = logging.getLogger("agent")

async def refinement_planner_node(state: AgentState, llm):
    """
    Decides the next move: PRUNE, FETCH, or READY.
    """
    iteration = state["iterations"]
    logger.info(f"--- [Refinement] Planning (Iter {iteration}) ---")
    
    ds = state["working_datasource"]
    question = state["question"]
    
    # 1. Format Context
    # We rely on the existing utils formatter
    context_md = AgentContextFormatter.datasource_to_markdown(ds)
    
    # 2. Chain
    planner = get_refinement_planner(llm)
    prompt = ChatPromptTemplate.from_messages([
        ("system", REFINEMENT_SYSTEM_PROMPT),
        ("human", "Question: {question}\nContext:\n{context_snapshot}")
    ])
    
    chain = prompt | planner
    # Using 'context_snapshot' to match prompt placeholder
    plan = await chain.ainvoke({
        "question": question, 
        "context_snapshot": context_md
    })
    
    logger.info(f"Decision: {plan.action_type} - {plan.status_reasoning[:100]}...")
    
    return {
        "refinement_plan": plan.model_dump(),
        "iterations": iteration + 1,
        "trace_log": [f"Refinement Iter {iteration}: {plan.action_type}"],
        "structured_logs": [{
             "step": "refinement_plan",
             "iteration": iteration,
             "plan": plan.model_dump()
        }]
    }

def pruner_worker_node(state: AgentState):
    """
    Executes PRUNE action.
    """
    logger.info("--- [Refinement] Pruning Context ---")
    plan = state["refinement_plan"] # dict or object? In state it's dict via model_dump
    
    # Re-hydrate wrapper for easier access or use dict
    # Let's use dict access for simplicity/speed
    targets = plan.get("prune_targets", [])
    if not targets:
        return {}

    ds = state["working_datasource"]
    
    # Optimization: pre-calculate sets
    tables_rm = {t["name"] for t in targets if t["object_type"] == "table"} # Using 'name' or 'slug'? Check Schema.
    # Schema says: name: str. Old logic used entity_slug. 
    # The new prompt asks for name. The formatter outputs names. 
    # Let's assume name based matching for simplicity or we need strict slugs.
    # Given the formatter, LLM sees "schema.table". 
    # Ideally we should match by what the LLM sees.
    
    # Let's try name matching.
    
    # ...Actually, safe bet is to filter.
    # New logic: prune from 'tables' list in ds dict.
    
    initial_t_count = len(ds.get("tables", []))
    ds["tables"] = [t for t in ds.get("tables", []) if t.get("name") not in tables_rm] # Assumes 'name' key matches
    
    # Deep pruning (Columns)
    cols_rm = {t["name"] for t in targets if t["object_type"] == "column"}
    count_c_pruned = 0
    if cols_rm:
        for t in ds.get("tables", []):
            original_cols = t.get("columns", [])
            t["columns"] = [c for c in original_cols if c.get("name") not in cols_rm]
            count_c_pruned += (len(original_cols) - len(t["columns"]))
            
    logger.info(f"Pruned {len(tables_rm)} tables, {count_c_pruned} columns.")

    return {
        "working_datasource": ds,
        "trace_log": [f"Pruned {len(tables_rm)} tables, {count_c_pruned} cols"],
        "structured_logs": [{
            "step": "pruner_worker",
            "pruned_tables_count": len(tables_rm),
            "pruned_columns_count": count_c_pruned
        }]
    }

async def fetch_worker_node(state: AgentState, discovery_service):
    """
    Executes FETCH action.
    """
    logger.info("--- [Refinement] Fetching Data ---")
    plan = state["refinement_plan"]
    targets = plan.get("fetch_targets", [])
    
    if not targets:
        return {}
        
    # Pick first target (simplification)
    target = targets[0]
    q = target["search_text"]
    etype = target["expected_type"]
    ds_slug = state["working_datasource"].get("slug")
    
    logger.info(f"Fetching '{q}' ({etype})...")
    
    results = []
    if etype == "table":
        results = await discovery_service.search_tables(q, ds_slug)
    elif etype == "column":
        results = await discovery_service.search_columns(q, ds_slug)
    elif etype == "metric":
        results = await discovery_service.search_metrics(q, ds_slug)
    # Add others as needed
    
    return {
        "pending_search_results": results,
        "current_fetch_target": target,
        "trace_log": [f"Fetched '{q}': {len(results)} items"],
        "structured_logs": [{
            "step": "fetch_worker",
            "target": target,
            "found_count": len(results)
        }]
    }

async def search_evaluator_node(state: AgentState, llm):
    """
    Evaluates search results and adds to context.
    """
    logger.info("--- [Refinement] Evaluating Results ---")
    target = state["current_fetch_target"]
    results = state["pending_search_results"]
    question = state["question"]
    
    if not results:
        return {"pending_search_results": []}

    # Format results
    results_txt = "\n".join([f"- {r.get('name', 'Unknown') }: {r.get('description', '')}" for r in results[:5]]) 
    
    # 2. Chain
    evaluator = get_search_evaluator(llm)
    prompt = ChatPromptTemplate.from_messages([
        ("system", EVALUATOR_SYSTEM_PROMPT), # prompt content injected
    ])
    
    # We construct prompt manually if using f-string in SYSTEM_PROMPT var?
    # No, chains/refinement_chains uses braces { } so it's a template.
    chain = prompt | evaluator
    
    evaluation = await chain.ainvoke({
        "search_text": target["search_text"],
        "results_snapshot": results_txt,
        "question": question
    })

    # 3. Update Context
    ds = state["working_datasource"]
    
    if not evaluation.is_irrelevant:
        note = f"FETCHED INFO [{target['search_text']}]: {evaluation.formatted_note}"
        logger.info(f"Added Valid Note: {note}")
        
        # Inject into top-level notes for now
        if "enrichment_notes" not in ds:
            ds["enrichment_notes"] = []
        ds["enrichment_notes"].append(note)
    else:
        logger.info("Discarded search results as irrelevant.")

    return {
        "working_datasource": ds,
        "pending_search_results": [],
        "trace_log": [f"Evaluation: {evaluation.reasoning}"],
        "structured_logs": [{
            "step": "search_evaluator",
            "evaluation": evaluation.model_dump()
        }]
    }
