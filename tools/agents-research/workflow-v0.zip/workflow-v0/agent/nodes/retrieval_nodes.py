import logging
import json
from agent.core.state import AgentState
from agent.chains.retrieval_chains import (
    get_search_planner, 
    get_datasource_selector, 
    SEARCH_SYSTEM_PROMPT, 
    SELECTION_SYSTEM_PROMPT
)
from utils.context_formatter import AgentContextFormatter
from langchain_core.prompts import ChatPromptTemplate

logger = logging.getLogger("agent")

async def search_planner_node(state: AgentState, llm):
    logger.info("--- [Retrieval] Planning Search ---")
    
    question = state["question"]
    
    # 1. Chain Setup
    planner = get_search_planner(llm)
    prompt = ChatPromptTemplate.from_messages([
        ("system", SEARCH_SYSTEM_PROMPT),
    ])
    chain = prompt | planner
    
    # 2. Invoke
    search_plan = await chain.ainvoke({"question": question})
    
    # 3. Log & Update
    log_msg = f"Search Plan: Strategy={search_plan.reasoning[:100]}... Terms={search_plan.query_terms}"
    logger.info(log_msg)
    
    return {
        "search_plan": search_plan.model_dump(),
        "trace_log": [log_msg],
        "structured_logs": [{
            "step": "plan_search",
            "content": search_plan.model_dump()
        }]
    }

async def retrieve_and_select_node(state: AgentState, llm, retrieval_service):
    logger.info("--- [Retrieval] Executing & Selecting ---")
    
    plan_dict = state["search_plan"]
    # Re-hydrate Pydantic model needed for service? 
    # The service now expects a custom SearchPlan or dict?
    # Our new service uses the new SearchPlan pydantic model.
    # We should reconstruct it from the dict in state.
    from agent.chains.retrieval_chains import SearchPlan
    plan = SearchPlan(**plan_dict)

    # 1. API Call
    response = await retrieval_service.execute_hierarchical_search(plan)
    count = len(response.graph) if response.graph else 0
    logger.info(f"Retrieved {count} candidates.")

    # 2. Format for LLM
    markdown_context = AgentContextFormatter.to_markdown(response)

    # 3. Selection Chain
    selector = get_datasource_selector(llm)
    prompt = ChatPromptTemplate.from_messages([
        ("system", SELECTION_SYSTEM_PROMPT),
    ])
    chain = prompt | selector
    
    decision = await chain.ainvoke({
        "question": state["question"], 
        "formatted_matches": markdown_context # Note: Prompt expects 'formatted_matches'
    })
    
    logger.info(f"Selected: {decision.selected_datasource_slug} - Reason: {decision.reasoning[:100]}")

    # 4. JSON Preservation (The Bridge)
    selected_json_obj = None
    if response.graph:
        for ds in response.graph:
            if ds.slug == decision.selected_datasource_slug:
                selected_json_obj = ds
                break
        
        # Fallback
        if not selected_json_obj:
            logger.warning("LLM hallucinated slug. Defaulting to first result.")
            selected_json_obj = response.graph[0]
            decision.selected_datasource_slug = selected_json_obj.slug

    # 5. Prepare Working Datasource (Mutable Copy)
    working_ds = selected_json_obj.model_dump() if hasattr(selected_json_obj, "model_dump") else dict(selected_json_obj)

    return {
        "working_datasource": working_ds,
        "trace_log": [f"Selected Datasource: {decision.selected_datasource_slug}"],
        "structured_logs": [{
            "step": "retrieval_selection",
            "retrieved_count": count,
            "selected_slug": decision.selected_datasource_slug,
            "reasoning": decision.reasoning
        }]
    }
