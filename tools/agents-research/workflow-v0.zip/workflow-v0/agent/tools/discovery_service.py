import httpx
from typing import List, Dict, Any, Optional
from agent.chains.retrieval_chains import SearchPlan
from src.schemas.discovery import ContextResolutionResponse, ContextSearchEntity

BASE_URL = "http://localhost:8000/api/v1/discovery"

class DiscoveryService:
    """
    Unified client for the Discovery API.
    Handles both Hierarchical Search (resolve-context) and Targeted Search.
    """
    
    async def _post(self, endpoint: str, payload: Dict[str, Any]) -> Any:
        async with httpx.AsyncClient() as client:
            try:
                url = f"{BASE_URL}{endpoint}"
                response = await client.post(url, json=payload, timeout=30.0)
                response.raise_for_status()
                return response.json()
            except Exception as e:
                # In production, log this error properly
                print(f"DiscoveryService Error [{endpoint}]: {e}")
                return {}

    # --- 1. Hierarchical Search (Phase 1) ---
    
    async def execute_hierarchical_search(self, plan: SearchPlan) -> ContextResolutionResponse:
        """
        Executes the 'resolve-context' endpoint based on the LLM SearchPlan.
        """
        items = []
        
        mapping = {
            "search_scope": [ # Heuristic mapping if plan has explicit scopes
                 # This part depends on how SearchPlan is defined in chains. 
                 # Let's map general terms to ContextSearchEntity if possible.
                 # Actually, SearchPlan has `query_terms` and `search_scope`.
            ],
            # We map explicit fields from the OLD plan if we want to keep parity, 
            # OR we primarily use the query terms. 
            # The previous logic mapped specific list fields (tables, columns) to entities.
            # The NEW SearchPlan uses a generic list of terms + scope.
            # let's simplify: search for terms across all scopes or specified scopes.
        }
        
        # For compatibility with the backend `resolve-context`, we need to generate specific items.
        # Let's use the query terms and apply them to standard entities based on scope.
        
        entities_to_searcy = []
        scopes = [s.lower() for s in plan.search_scope]
        
        if "tables" in scopes or not scopes:
             entities_to_searcy.append(ContextSearchEntity.TABLES)
        if "columns" in scopes:
             entities_to_searcy.append(ContextSearchEntity.COLUMNS)
        if "metrics" in scopes:
             entities_to_searcy.append(ContextSearchEntity.METRICS)
        # Always include Goldens/Context rules if query is generic? 
        # Let's stick to what the plan says roughly.
        
        # To be safe and robust:
        # If the plan says "search for users", we search users in TABLES, COLUMNS, METRICS.
        
        search_items = []
        for term in plan.query_terms:
            # Default set of entities to search per term
            target_entities = [
                ContextSearchEntity.TABLES,
                ContextSearchEntity.COLUMNS,
                ContextSearchEntity.METRICS
            ]
            
            for ent in target_entities:
                search_items.append({
                    "entity": ent.value,
                    "search_text": term,
                    "min_ratio_to_best": 0.75
                })
                
        # Call API
        response_json = await self._post("/resolve-context", search_items)
        
        if not response_json:
            return ContextResolutionResponse(items=[])
            
        return ContextResolutionResponse(**response_json)

    # --- 2. Targeted Search (Phase 2 Refinement) ---

    async def search_tables(self, query: str, datasource_slug: str) -> List[Any]:
        data = await self._post("/tables", {
            "query": query, "datasource_slug": datasource_slug,
            "page": 1, "limit": 10, "min_ratio_to_best": 0.75
        })
        return data.get("items", [])

    async def search_columns(self, query: str, datasource_slug: str) -> List[Any]:
        data = await self._post("/columns", {
            "query": query, "datasource_slug": datasource_slug,
            "page": 1, "limit": 10, "min_ratio_to_best": 0.75
        })
        return data.get("items", [])

    async def search_metrics(self, query: str, datasource_slug: str) -> List[Any]:
        data = await self._post("/metrics", {
            "query": query, "datasource_slug": datasource_slug,
            "page": 1, "limit": 10, "min_ratio_to_best": 0.75
        })
        return data.get("items", [])
