import os
import sys
import uuid
import asyncio
import json
import datetime
from langchain_openai import ChatOpenAI

# Ensure environment is loaded BEFORE other imports
current_dir = os.path.dirname(os.path.abspath(__file__))
project_root = os.path.dirname(os.path.dirname(os.path.dirname(current_dir)))
sys.path.append(project_root)

try:
    from dotenv import load_dotenv
    load_dotenv(os.path.join(project_root, ".env"))
except ImportError:
    pass

from agent.graph import build_graph

# --- Setup Dependencies ---
llm = ChatOpenAI(model="gpt-4o", temperature=0)

# --- Initialize App ---
app = build_graph(llm)

async def main():
    print("Agent Chat (Domain-Driven v2)")
    print("----------------------------")
    
    # Base logs directory
    base_logs = os.path.join(current_dir, "logs")
    os.makedirs(base_logs, exist_ok=True)
    
    thread_id = str(uuid.uuid4())
    config = {"configurable": {"thread_id": thread_id}}
    
    while True:
        try:
            user_input = input("\nUser: ")
            if user_input.lower() in ["quit", "exit", "q"]:
                break
            
            # --- Initialization ---
            inputs = {
                "question": user_input,
                "iterations": 0,
                "structured_logs": [],   # Start empty
                "trace_log": [] # Start empty
            }
            
            # Run Log Directory
            ts = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
            run_id = f"{ts}_{uuid.uuid4().hex[:4]}"
            run_dir = os.path.join(base_logs, run_id)
            os.makedirs(run_dir, exist_ok=True)
            
            print("🚀 Processing...")
            
            final_state = {}
            
            # Stream Updates (Node outputs)
            async for event in app.astream(inputs, config=config):
                for node_name, state_update in event.items():
                    # 1. Console Tracing (The "Thought Process")
                    if "trace_log" in state_update:
                        for trace in state_update["trace_log"]:
                            # Print with color/formatting
                            print(f"\n[Agent]: {trace}")
                            
                    # Capture final state as we go (simplification: last update usually contains needed info logic, 
                    # but for full state we might want the values).
                    # Actually astream returns the delta. 
                    # We need the FINAL full state for JSON dumping.
            
            # Retrieve Final State explicitly to get the Full Accumulated Logs
            # Note: app.astream yields updates. The 'state_update' only has the delta.
            # We need to fetch the final state from Memory or accumulate it manually?
            # LangGraph astream yields the output of the node. 
            # The 'structured_logs' in state_update IS the delta (the list of new logs).
            # We can accumulate them here for saving.
            
            full_logs = []
            # But wait, checking the graph state is safer.
            # How to get valid state after execution?
            # app.invoke(inputs) returns final state. astream yields events.
            # To get full state at end:
            # We can use app.get_state(config) if using Checkpointer.
            # We are using MemorySaver? No, explicit MemorySaver was removed in my graph.py build.
            # So state is ephemeral.
            
            # Re-strategy: Accumulate structured_logs from the stream events.
            
            final_context = None
            
    # --- REDO STREAM LOOP TO ACCUMULATE ---
            
            accumulated_logs = []
            
            # Re-running logic (conceptual)
            # Actually, I can just do `invoke` if I don't need streaming print. 
            # But I WANT streaming print.
            # So I will accumulate.
            
    # Start fresh loop logic for clarity (shadowing above)
    
            async for event in app.astream(inputs, config=config):
                 for node_name, state_update in event.items():
                     
                     # 1. Trace (Console)
                     if "trace_log" in state_update:
                         for trace in state_update["trace_log"]:
                             print(f"[{node_name}] {trace}")
                             
                     # 2. Accumulate Structured Logs
                     if "structured_logs" in state_update:
                         accumulated_logs.extend(state_update["structured_logs"])
                         
                     # 3. Capture Working Datasource updates
                     if "working_datasource" in state_update:
                         final_context = state_update["working_datasource"]

            # --- Save Logs ---
            if accumulated_logs:
                # Filter
                retrieval_steps = ["plan_search", "retrieval_selection"]
                ref_steps = ["refinement_plan", "pruner_worker", "fetch_worker", "search_evaluator"]
                
                retrieval_logs = [l for l in accumulated_logs if l["step"] in retrieval_steps]
                refinement_logs = [l for l in accumulated_logs if l["step"] in ref_steps]
                
                # 1. Retrieval
                with open(os.path.join(run_dir, "retrieval_log.json"), "w") as f:
                    json.dump({"question": user_input, "logs": retrieval_logs}, f, indent=2, default=str)
                    
                # 2. Refinement
                with open(os.path.join(run_dir, "refinement_log.json"), "w") as f:
                    json.dump({
                        "question": user_input, 
                        "logs": refinement_logs,
                        "final_context_snapshot": final_context
                    }, f, indent=2, default=str)
                    
                print(f"\n[Logs Saved]: {run_dir}")
                
            if final_context:
                print("\nFinal Context Updated.")

        except KeyboardInterrupt:
            break
        except Exception as e:
            import traceback
            traceback.print_exc()

if __name__ == "__main__":
    asyncio.run(main())