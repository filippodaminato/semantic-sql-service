
import sys
import os
import asyncio
from unittest import TestCase
from unittest.mock import MagicMock, AsyncMock

# Add project root and workflow root to sys.path
sys.path.append(os.getcwd())
sys.path.append(os.path.join(os.getcwd(), "tools/agents-research/workflow-v0"))

from refinement.graph import create_refinement_graph
from refinement.schemas import QueryPlan, FetchTarget, PruneTarget, SearchEvaluation
from state import AgentState

# Mock Data
INITIAL_DATASOURCE = {
    "name": "Test DB",
    "slug": "test_db",
    "tables": [
        {"physical_name": "t1", "slug": "db.t1", "columns": [{"name": "c1", "slug": "db.t1.c1"}]},
        {"physical_name": "t2", "slug": "db.t2", "columns": []}
    ]
}

class TestRefinementGraph(TestCase):
    
    def test_full_loop(self):
        asyncio.run(self._async_test_full_loop())

    async def _async_test_full_loop(self):
        print("\n--- Starting Integration Test ---\n")
        
        # 1. Setup Mock LLM
        mock_llm = MagicMock()
        mock_llm_runnable = MagicMock()
        mock_llm.with_structured_output.return_value = mock_llm_runnable
        mock_llm_runnable.ainvoke = AsyncMock() # Ensure ainvoke is awaitable
        
        # We need to simulate a sequence of LLM calls.
        # The graph calls LLM in:
        # - Planner (returns QueryPlan)
        # - Search Evaluator (returns SearchEvaluation)
        
        # Let's define the sequence of EXPECTED RESPONSES.
        # Sequence:
        # 1. Planner -> FETCH "something"
        # 2. (Fetch Worker runs, finds something - mocked via patch or simpler: we trust fetch worker does its job or we mock the tool)
        #    Wait, fetch_worker calls 'refinement_tools'. We should probably mock that too or let it fail gracefully/return empty. 
        #    Ideally we mock the tools. But for graph wiring, let's see.
        #    If we can't easily mock tools.py, we can just ensure FetchTarget is valid.
        #    But fetch_worker calls network. We must mock the tools in `refinement.nodes`.
        
        # 3. Evaluator -> Keep it
        # 4. Planner -> PRUNE "t2"
        # 5. Planner -> READY
        
        # Define Plans
        plan_1_fetch = QueryPlan(
            status_reasoning="Need info",
            action_type="FETCH",
            fetch_targets=[FetchTarget(entity_type="table", search_text="query1")]
        )
        
        plan_2_prune = QueryPlan(
            status_reasoning="Too much data",
            action_type="PRUNE",
            prune_targets=[PruneTarget(entity_type="table", entity_slug="db.t2")]
        )
        
        plan_3_ready = QueryPlan(
            status_reasoning="All good",
            action_type="READY",
            final_sql_logic=["SELECT * FROM t1"]
        )
        
        evaluation_result = SearchEvaluation(
            selected_indices=[0],
            reasoning="Good match",
            formatted_note="Enriched Info",
            is_irrelevant=False
        )
        
        # We need to control who gets what response. 
        # planner_node calls: llm.with_structured_output(QueryPlan).ainvoke(...)
        # evaluation_node calls: llm.with_structured_output(SearchEvaluation).ainvoke(...)
        
        # Since 'with_structured_output' is called with different classes, we can distinguish by checking call args 
        # or simpler: just use side_effect on a single mocked ainvoke if they share the mock, 
        # OR better, mock 'planner_node' and 'search_evaluator_node' functionality?
        # No, we want to test the graph wiring.
        
        # Let's simple side_effect based on call order.
        # Logic flow:
        # 1. Planner calls (Expects QueryPlan) -> returns plan_1_fetch
        # 2. FetchWorker runs (calls tools)
        # 3. Evaluator calls (Expects SearchEvaluation) -> returns evaluation_result
        # 4. Planner calls (Expects QueryPlan) -> returns plan_2_prune
        # 5. Pruner runs
        # 6. Planner calls (Expects QueryPlan) -> returns plan_3_ready
        
        mock_llm_runnable.ainvoke.side_effect = [
            plan_1_fetch,       # 1. Planner
            evaluation_result,  # 3. Evaluator
            plan_2_prune,       # 4. Planner
            plan_3_ready        # 6. Planner
        ]

        # 2. Mock Internal Tools (Network calls)
        # We need to patch refinement.nodes.refinement_tools
        from unittest.mock import patch
        
        with patch("refinement.nodes.refinement_tools") as mock_tools:
            # Mock search result
            mock_tools.search_tables = AsyncMock() # Ensure it is awaitable
            mock_tools.search_tables.return_value = [{"physical_name": "found_table", "semantic_name": "Found", "description": "desc"}]
            
            # 3. Create Graph
            graph = create_refinement_graph(mock_llm)
        
            initial_state = AgentState(
                question="Test Question",
                working_datasource=INITIAL_DATASOURCE.copy(),
                iterations=0,
                current_plan=None,
                pending_search_results=[],
                current_fetch_target=None
            )
            
            print("Invoking Graph...")
            final_state = await graph.ainvoke(initial_state, config={"recursion_limit": 10})
            
            print("Graph finished.")
            
            # 4. Assertions
            
            # Check flows
            self.assertEqual(final_state["current_plan"].action_type, "READY")
            self.assertEqual(final_state["iterations"], 3) # 0->1(fetch), 1->2(prune), 2->3(ready)
            
            # Check modifications
            # 1. Pruning happened? "t2" should be gone.
            tables = final_state["working_datasource"]["tables"]
            self.assertEqual(len(tables), 1)
            self.assertEqual(tables[0]["slug"], "db.t1")
            
            # 2. Enrichment happened?
            notes = final_state["working_datasource"].get("enrichment_notes", [])
            print(f"Notes: {notes}")
            self.assertTrue(any("Enriched Info" in n for n in notes))
            
            print("Integration Test Passed ✅")

if __name__ == "__main__":
    t = TestRefinementGraph()
    t.test_full_loop()
