from typing import Any
from src.schemas.discovery import ContextResolutionResponse

class AgentContextFormatter:
    
    @staticmethod
    def to_markdown(response: ContextResolutionResponse) -> str:
        """
        Converts the hierarchical context response into a clean, token-efficient 
        Markdown format optimized for LLM ingestion.
        """
        blocks = []
        for ds in response.graph:
            # Sfruttiamo il metodo statico per formattare ogni singolo datasource
            blocks.append(AgentContextFormatter.datasource_to_markdown(ds))
            
        return "\n".join(blocks)

    @staticmethod
    def datasource_to_markdown(ds: Any) -> str:
        """
        Converts a single Datasource object (or dict) into markdown.
        Handles both Pydantic models and dictionaries (for refinement loop compatibility).
        """
        # Helper per accesso attributi/dict
        def get_val(obj, key, default=None):
            if isinstance(obj, dict):
                return obj.get(key, default)
            return getattr(obj, key, default)

        ds_name = get_val(ds, "name", "Unknown")
        ds_slug = get_val(ds, "slug", "")
        ds_desc = get_val(ds, "description", "")
        
        ds_block = []
        
        # 1. Livello Datasource
        ds_block.append(f"# Datasource: `{ds_name}`")
        ds_block.append(f"- **Slug**: {ds_slug}")
        if ds_desc:
            ds_block.append(f"- **Usage**: {ds_desc} \n")
        
        # 2. Livello Tabelle
        tables = get_val(ds, "tables", [])
        if tables:
            ds_block.append(f"## Founded Tables:")
            for table in tables:
                t_phys_name = get_val(table, "physical_name", "")
                t_slug = get_val(table, "slug", "")
                t_desc = get_val(table, "description", None)
                
                ds_block.append(f"### Table: `{t_phys_name}` ")
                ds_block.append(f"- **Slug**: `{t_slug}`")
                ds_block.append(f"- **Usage**: {t_desc or 'No description available.'}")
                
                # 3. Livello Colonne
                columns = get_val(table, "columns", [])
                if columns:
                    ds_block.append(f"\n#### Founded Columns:")
                    for col in columns:
                        c_name = get_val(col, "name", "")
                        c_slug = get_val(col, "slug", "")
                        c_type = get_val(col, "data_type", "")
                        c_desc = get_val(col, "description", "")
                        c_note = get_val(col, "context_note", "")
                        
                        ds_block.append(f"##### Column: `{c_name}` ")
                        ds_block.append(f"- **Slug**: `{c_slug}`")

                        if c_type:
                            ds_block.append(f"- **Type**: `{c_type}`")
                        
                        if c_desc:
                            ds_block.append(f"- **Desc**: `{c_desc}`")

                        if c_note:
                            ds_block.append(f"- **Notes**: `{c_note}`")

                        # 4a. Nominal Values
                        nominal_values = get_val(col, "nominal_values", [])
                        if nominal_values:
                            # Gestione dict o object
                            vals = []
                            for v in nominal_values:
                                val_raw = v.get("value_raw") if isinstance(v, dict) else v.value_raw
                                vals.append(val_raw)
                            
                            val_str = ", ".join(vals[:5])
                            if len(vals) > 5:
                                val_str += ", ..."
                            ds_block.append(f"> Nominal Values: {val_str}")

                        # 4b. Context Rules
                        context_rules = get_val(col, "context_rules", [])
                        if context_rules:
                            for rule in context_rules:
                                r_text = rule.get("rule_text") if isinstance(rule, dict) else rule.rule_text
                                ds_block.append(f"> Context Rule: {r_text}")
                        ds_block.append("\n")
            
        # 5. Metrics
        metrics = get_val(ds, "metrics", [])
        if metrics:
            ds_block.append("\n### Semantic Metrics")
            for metric in metrics:
                m_name = get_val(metric, "name", "")
                m_slug = get_val(metric, "slug", "")
                m_desc = get_val(metric, "description", "")
                m_sql = get_val(metric, "calculation_sql", "")
                
                ds_block.append(f"- **{m_name}**")
                ds_block.append(f"- **Slug**: `{m_slug}`")
                if m_desc:
                    ds_block.append(f"- Desc : {m_desc}")
                ds_block.append(f"- SQL: `{m_sql}`")
            ds_block.append("\n---")
        
        # 6. Edges
        edges = get_val(ds, "edges", [])
        if edges:
            ds_block.append("\n### Relationships")
            for edge in edges:
                e_source = get_val(edge, "source", "")
                e_target = get_val(edge, "target", "")
                e_rel = get_val(edge, "relationship_type", "")
                e_desc = get_val(edge, "description", "")
                
                ds_block.append(f"- `{e_source}` -> `{e_target}` ({e_rel})")
                if e_desc:
                        ds_block.append(f"- _{e_desc}_")
            ds_block.append("\n---")

        # 7. Golden SQL
        golden_sqls = get_val(ds, "golden_sqls", [])
        if golden_sqls:
            ds_block.append("\n### Golden SQL Examples")
            for gs in golden_sqls:
                gs_prompt = get_val(gs, "prompt", "")
                ds_block.append(f"- **Prompt**: \"{gs_prompt}\"")
            ds_block.append("\n---")
        
        # NEW: Enrichment Notes (Injected during search evaluation)
        enrichment_notes = get_val(ds, "enrichment_notes", [])
        if enrichment_notes:
             ds_block.append("\n### 🧠 Agent Knowledge Notes")
             for note in enrichment_notes:
                 ds_block.append(f"> {note}")
             ds_block.append("\n---")

        return "\n".join(ds_block)

    @staticmethod
    def entity_to_markdown(entity: Any) -> str:
        """
        Converts a generic search result entity into a markdown string for the Evaluator.
        """
        # Helper per accesso attributi/dict
        def get_val(obj, key, default=None):
            if isinstance(obj, dict):
                return obj.get(key, default)
            return getattr(obj, key, default)

        # Riconoscimento tipo basato su campi comuni
        # TODO: Sarebbe meglio avere un campo 'type' esplicito dai wrapper
        
        # Table
        if get_val(entity, "physical_name"):
            name = get_val(entity, "physical_name")
            semantic = get_val(entity, "semantic_name")
            desc = get_val(entity, "description")
            return f"**Table**: `{name}` ({semantic})\n   Desc: {desc}"
            
        # Column
        if get_val(entity, "data_type"): # Forte indizio colonna
             name = get_val(entity, "name")
             dtype = get_val(entity, "data_type")
             desc = get_val(entity, "description")
             return f"**Column**: `{name}` ({dtype})\n   Desc: {desc}"

        # Metric
        if get_val(entity, "calculation_sql"):
            name = get_val(entity, "name")
            desc = get_val(entity, "description")
            return f"**Metric**: `{name}`\n   Desc: {desc}"

        # Value
        if get_val(entity, "value_raw"):
             val = get_val(entity, "value_raw")
             label = get_val(entity, "value_label", "")
             return f"**Value**: `{val}` ({label})"

        # Fallback generico
        return str(entity)